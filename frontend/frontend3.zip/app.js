const baseUrl =
  window.location.origin && window.location.origin !== "null"
    ? window.location.origin
    : "http://localhost:3000";
let currentEditEventId = null;
let currentEditGalleryId = null;
let adminAuthenticated = false;

async function uploadImageFile(file) {
  if (!file) return null;
  const formData = new FormData();
  formData.append("file", file);

  const res = await fetch(`${baseUrl}/api/uploads`, {
    method: "POST",
    body: formData,
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || "Unable to upload image.");
  }

  return data.filename || data.url;
}

async function uploadGalleryImages(files) {
  const uploadedImages = [];
  for (const file of files || []) {
    const uploaded = await uploadImageFile(file);
    if (uploaded) {
      uploadedImages.push(uploaded);
    }
  }
  return uploadedImages;
}

function normalizeGalleryImages(images) {
  if (!images) return [];
  if (Array.isArray(images)) {
    return images.map((image) => String(image || "").trim()).filter(Boolean);
  }

  if (typeof images === "string") {
    const trimmed = images.trim();
    if (!trimmed) return [];

    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        return parsed.map((image) => String(image || "").trim()).filter(Boolean);
      }
    } catch (err) {
      return trimmed
        .split(",")
        .map((image) => String(image || "").trim())
        .filter(Boolean);
    }
  }

  return [];
}

const mainMessage = document.getElementById("mainMessage");
const adminMessage = document.getElementById("adminMessage");
const adminAccessMessage = document.getElementById("adminAccessMessage");
const adminLoginForm = document.getElementById("adminLoginForm");
const adminPasswordInput = document.getElementById("adminPassword");
const adminLogoutButton = document.getElementById("adminLogout");
const modalMessage = document.getElementById("modalMessage");
const orderMessage = document.getElementById("orderMessage");
const adminSection = document.getElementById("admin-section");
const registrationModal = document.getElementById("registrationModal");
const orderModal = document.getElementById("orderModal");
const imageViewerModal = document.getElementById("imageViewerModal");
const imageViewerImg = document.getElementById("imageViewerImg");

function isAdminPanelVisible() {
  return Boolean(adminAuthenticated && adminSection && !adminSection.classList.contains("hidden"));
}

function updateAdminControls() {
  const adminToggle = document.getElementById("adminToggle");
  if (adminToggle) {
    if (!adminAuthenticated) {
      adminToggle.textContent = "Admin Login";
    } else {
      adminToggle.textContent = adminSection.classList.contains("hidden")
        ? "Open Admin Dashboard"
        : "Hide Admin Dashboard";
    }
  }

  if (adminLogoutButton) {
    adminLogoutButton.classList.toggle("hidden", !adminAuthenticated);
  }
}

function setAdminMode(enabled) {
  if (!adminSection) return;
  adminSection.classList.toggle("hidden", !enabled);
  if (!enabled) {
    hideAdminLoginForm();
  }
  updateAdminControls();
  loadEvents();
  loadGallery();
  if (enabled) {
    loadRegistrations();
    loadProducts(true);
    loadPartners(true);
    loadOrders();
  }
}

function isPastEvent(event) {
  const status = String(event?.status || "").toLowerCase();
  if (status === "past") return true;
  if (status === "upcoming") return false;

  const date = String(event?.date || "").trim();
  const time = String(event?.time || "").trim() || "00:00";
  if (!date) return false;

  const parsed = new Date(`${date}T${time}:00`);
  if (Number.isNaN(parsed.valueOf())) return false;
  return parsed.getTime() < Date.now();
}

function getEventSortValue(event) {
  const date = String(event?.date || "").trim();
  const time = String(event?.time || "").trim() || "00:00";
  const parsed = new Date(`${date}T${time}:00`);
  return Number.isNaN(parsed.valueOf()) ? 0 : parsed.getTime();
}

async function loadEvents() {
  const eventsDiv = document.getElementById("events");
  const archivedEventsDiv = document.getElementById("archivedEvents");
  eventsDiv.innerHTML =
    "<p class='status-message status-loading'>Loading events...</p>";
  if (archivedEventsDiv) {
    archivedEventsDiv.innerHTML = "";
  }

  try {
    const res = await fetch(`${baseUrl}/api/events`);
    if (!res.ok) {
      throw new Error("Failed to fetch events");
    }

    const events = await res.json();
    const upcomingEvents = events
      .filter((event) => !isPastEvent(event))
      .sort((a, b) => getEventSortValue(a) - getEventSortValue(b));
    const archivedEvents = events
      .filter((event) => isPastEvent(event))
      .sort((a, b) => getEventSortValue(b) - getEventSortValue(a));
    eventsDiv.innerHTML = "";

    if (!upcomingEvents.length) {
      eventsDiv.innerHTML =
        "<p class='status-message status-empty'>No upcoming events available at the moment.</p>";
    } else {
      upcomingEvents.forEach((event) => {
        eventsDiv.appendChild(renderEventCard(event));
      });
    }

    if (archivedEventsDiv) {
      if (isAdminPanelVisible()) {
        archivedEventsDiv.innerHTML = "";
        if (!archivedEvents.length) {
          archivedEventsDiv.innerHTML =
            "<p class='status-message status-empty'>No archived events yet.</p>";
        } else {
          archivedEvents.forEach((event) => {
            archivedEventsDiv.appendChild(
              renderEventCard(event, { adminView: true, archived: true }),
            );
          });
        }
      } else {
        archivedEventsDiv.innerHTML = "";
      }
    }
  } catch (err) {
    console.error("Error loading events:", err);
    eventsDiv.innerHTML =
      "<p class='status-message status-error'>Unable to load events. Please try again later.</p>";
    if (archivedEventsDiv) {
      archivedEventsDiv.innerHTML = "";
    }
  }
}

function renderEventCard(event, options = {}) {
  const { adminView = false, archived = false } = options;
  const card = document.createElement("article");
  card.className = archived ? "event-card event-card--archived" : "event-card";

  const image = document.createElement("img");
  image.src =
    resolveAssetUrl(event.image) ||
    "https://via.placeholder.com/460x260?text=Event+Image";
  image.alt = event.name;
  image.className = "event-image";
  attachImagePreview(image, event.name, "Event poster");

  if (archived) {
    const badge = document.createElement("span");
    badge.className = "event-badge event-badge--archived";
    badge.textContent = "Archived";
    card.appendChild(badge);
  }

  const title = document.createElement("h3");
  title.textContent = event.name;

  const description = document.createElement("p");
  description.textContent = event.description || "No description available.";
  description.className = "event-description";

  const meta = document.createElement("p");
  meta.className = "event-meta";
  meta.innerHTML = `<strong>Date:</strong> ${formatDate(event.date)} | <strong>Time:</strong> ${formatTime(event.time)} | <strong>Location:</strong> ${event.location || "TBA"}${archived ? " | <strong>Status:</strong> Archived" : ""}`;

  const actions = document.createElement("div");
  actions.className = "button-row";

  if (!archived) {
    const registerBtn = document.createElement("button");
    registerBtn.type = "button";
    registerBtn.className = "secondary-btn";
    registerBtn.textContent = "Register";
    registerBtn.addEventListener("click", () => openRegistrationModal(event));
    actions.appendChild(registerBtn);
  }

  if (adminView || isAdminPanelVisible()) {
    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "secondary-btn";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => fillEventForm(event));
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "danger-btn";
    deleteBtn.textContent = "Delete";
    deleteBtn.addEventListener("click", () => deleteEvent(event.id));
    actions.appendChild(deleteBtn);
  }

  card.append(image, title, description, meta, actions);
  return card;
}

function openRegistrationModal(event) {
  if (isPastEvent(event)) {
    showMessage(mainMessage, "This event has already passed.", "error");
    return;
  }

  hideMessage(mainMessage);
  hideMessage(modalMessage);
  document.getElementById("modalEventTitle").textContent = event.name;
  document.getElementById("modalEventId").value = event.id;
  registrationModal.classList.remove("hidden");
}

function closeRegistrationModal() {
  hideMessage(modalMessage);
  document.getElementById("registerForm").reset();
  registrationModal.classList.add("hidden");
}

async function submitRegistration(event) {
  event.preventDefault();
  hideMessage(modalMessage);

  const eventId = document.getElementById("modalEventId").value;
  const name = document.getElementById("registerName").value.trim();
  const email = document.getElementById("registerEmail").value.trim();
  const phone = document.getElementById("registerPhone").value.trim();
  const foodAllergies = document.getElementById("registerAllergies").value.trim();
  const additionalInfo = document
    .getElementById("registerAdditionalInfo")
    .value.trim();

  if (!name || !email || !phone) {
    showMessage(
      modalMessage,
      "Please fill in every field before submitting.",
      "error",
    );
    return;
  }

  if (!validateEmail(email)) {
    showMessage(modalMessage, "Please enter a valid email address.", "error");
    return;
  }

  try {
    const res = await fetch(`${baseUrl}/api/registrations`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        event_id: Number(eventId),
        name,
        email,
        phone,
        food_allergies: foodAllergies,
        additional_info: additionalInfo,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message || "Registration failed");
    }

    showMessage(
      mainMessage,
      data.message || "You are registered successfully!",
      "success",
    );
    closeRegistrationModal();
    mainMessage.scrollIntoView({ behavior: "smooth", block: "center" });
  } catch (err) {
    console.error("Registration failed:", err);
    showMessage(
      modalMessage,
      err.message || "Unable to complete registration.",
      "error",
    );
  }
}

function openOrderModal(product) {
  hideMessage(mainMessage);
  hideMessage(orderMessage);
  document.getElementById("modalProductTitle").textContent = product.name;
  document.getElementById("modalProductId").value = product.id;
  orderModal.classList.remove("hidden");
}

function closeOrderModal() {
  hideMessage(orderMessage);
  document.getElementById("orderForm").reset();
  orderModal.classList.add("hidden");
}

async function submitOrder(event) {
  event.preventDefault();
  hideMessage(orderMessage);

  const productId = document.getElementById("modalProductId").value;
  const quantity = parseInt(document.getElementById("orderQuantity").value);
  const name = document.getElementById("orderName").value.trim();
  const email = document.getElementById("orderEmail").value.trim();
  const phone = document.getElementById("orderPhone").value.trim();

  if (!name || !email || !phone || quantity < 1) {
    showMessage(
      orderMessage,
      "Please fill in all fields with valid information.",
      "error",
    );
    return;
  }

  if (!validateEmail(email)) {
    showMessage(orderMessage, "Please enter a valid email address.", "error");
    return;
  }

  try {
    const res = await fetch(`${baseUrl}/api/orders`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        product_id: Number(productId),
        quantity,
        customer_name: name,
        customer_email: email,
        customer_phone: phone,
      }),
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message || "Order failed");
    }

    showMessage(
      mainMessage,
      data.message || "Order placed successfully! Admin will be notified.",
      "success",
    );
    closeOrderModal();
  } catch (err) {
    console.error("Order failed:", err);
    showMessage(orderMessage, err.message || "Unable to place order.", "error");
  }
}

function fillEventForm(event) {
  currentEditEventId = event.id;
  document.getElementById("eventId").value = event.id;
  document.getElementById("name").value = event.name;
  document.getElementById("location").value = event.location;
  document.getElementById("date").value = event.date;
  document.getElementById("time").value = event.time || "";
  document.getElementById("eventImage").value = event.image || "";
  document.getElementById("eventImageFile").value = "";
  document.getElementById("description").value = event.description || "";

  document.getElementById("cancelEdit").classList.remove("hidden");
  showMessage(
    adminMessage,
    "Editing event. Update the fields and save.",
    "success",
  );
}

function resetEventForm() {
  currentEditEventId = null;
  document.getElementById("eventForm").reset();
  document.getElementById("eventId").value = "";
  document.getElementById("eventImageFile").value = "";
  document.getElementById("cancelEdit").classList.add("hidden");
  hideMessage(adminMessage);
}

async function submitEventForm(e) {
  e.preventDefault();
  hideMessage(adminMessage);

  try {
    const name = document.getElementById("name").value.trim();
    const date = document.getElementById("date").value;
    const time = document.getElementById("time").value;
    const location = document.getElementById("location").value.trim();
    const imageInput = document.getElementById("eventImage").value.trim();
    const imageFile = document.getElementById("eventImageFile").files[0];
    let image = imageInput;
    const description = document.getElementById("description").value.trim();

    if (!name || !date || !time || !location) {
      showMessage(
        adminMessage,
        "Name, date, time, and location are required.",
        "error",
      );
      return;
    }

    if (imageFile) {
      image = await uploadImageFile(imageFile);
    }

    const payload = { name, date, time, location, description, image };
    const url = currentEditEventId
      ? `${baseUrl}/api/events/${currentEditEventId}`
      : `${baseUrl}/api/events`;
    const method = currentEditEventId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Unable to save event.");
    }

    showMessage(
      adminMessage,
      data.message || "Event saved successfully.",
      "success",
    );
    resetEventForm();
    loadEvents();
  } catch (err) {
    console.error("Error saving event:", err);
    showMessage(adminMessage, err.message || "Failed to save event.", "error");
  }
}

function showAdminAccessMessage(text, type = "success") {
  showMessage(adminAccessMessage, text, type);
}

function hideAdminAccessMessage() {
  hideMessage(adminAccessMessage);
}

function showAdminLoginForm() {
  if (!adminLoginForm) return;
  adminLoginForm.classList.remove("hidden");
  if (adminPasswordInput) {
    adminPasswordInput.focus();
  }
}

function hideAdminLoginForm() {
  if (!adminLoginForm) return;
  adminLoginForm.classList.add("hidden");
  if (adminLoginForm) {
    adminLoginForm.reset();
  }
}

async function checkAdminSession() {
  try {
    const res = await fetch(`${baseUrl}/api/auth/me`);
    const data = await res.json();
    adminAuthenticated = Boolean(data.authenticated);
  } catch (err) {
    adminAuthenticated = false;
  }

  if (adminAuthenticated) {
    updateAdminControls();
  } else {
    hideAdminPanel();
  }
}

async function deleteEvent(eventId) {
  const confirmed = confirm("Delete this event? This cannot be undone.");
  if (!confirmed) return;

  try {
    const res = await fetch(`${baseUrl}/api/events/${eventId}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || data.error || "Could not delete event.");
    }

    showMessage(
      adminMessage,
      data.message || "Event removed successfully.",
      "success",
    );
    if (currentEditEventId === eventId) {
      resetEventForm();
    }
    loadEvents();
  } catch (err) {
    console.error("Error deleting event:", err);
    showMessage(
      adminMessage,
      err.message || "Unable to remove event.",
      "error",
    );
  }
}

async function loadProducts(isAdmin = false) {
  const productsDiv = document.getElementById(
    isAdmin ? "admin-products" : "products",
  );
  productsDiv.innerHTML =
    "<p class='status-message status-loading'>Loading products...</p>";

  try {
    const res = await fetch(`${baseUrl}/api/products`);
    if (!res.ok) {
      throw new Error("Failed to fetch products");
    }

    const products = await res.json();
    productsDiv.innerHTML = "";

    if (!products.length) {
      productsDiv.innerHTML = isAdmin
        ? "<p class='status-message status-empty'>No products available.</p>"
        : "<p class='status-message status-empty'>No products available at the moment.</p>";
      return;
    }

    products.forEach((product) => {
      productsDiv.appendChild(renderProductCard(product, isAdmin));
    });
  } catch (err) {
    console.error("Error loading products:", err);
    productsDiv.innerHTML =
      "<p class='status-message status-error'>Unable to load products. Please try again later.</p>";
  }
}

function renderProductCard(product, isAdmin = false) {
  const card = document.createElement("article");
  card.className = "product-card";

  const title = document.createElement("h4");
  title.textContent = product.name;

  const description = document.createElement("p");
  description.textContent = product.description || "No description available.";
  description.className = "product-description";

  const price = document.createElement("p");
  price.className = "product-price";
  price.textContent = formatCurrency(product.price);

  const image = document.createElement("img");
  image.src =
    resolveAssetUrl(product.image) ||
    "https://via.placeholder.com/150x150?text=No+Image";
  image.alt = product.name;
  image.className = "product-image";
  attachImagePreview(image, product.name, "Product image");

  const actions = document.createElement("div");
  actions.className = "button-row";

  if (isAdmin) {
    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "secondary-btn";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => fillProductForm(product));
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "danger-btn";
    deleteBtn.textContent = "Delete";
    deleteBtn.addEventListener("click", () => deleteProduct(product.id));
    actions.appendChild(deleteBtn);
  } else {
    const buyBtn = document.createElement("button");
    buyBtn.type = "button";
    buyBtn.className = "primary-btn";
    buyBtn.textContent = "Buy Now";
    buyBtn.addEventListener("click", () => openOrderModal(product));
    actions.appendChild(buyBtn);
  }

  card.append(title, image, description, price, actions);
  return card;
}

function fillProductForm(product) {
  document.getElementById("productId").value = product.id;
  document.getElementById("productName").value = product.name;
  document.getElementById("productPrice").value = product.price;
  document.getElementById("productImage").value = product.image || "";
  document.getElementById("productImageFile").value = "";
  document.getElementById("productDescription").value =
    product.description || "";

  document.getElementById("cancelProductEdit").classList.remove("hidden");
  showMessage(
    adminMessage,
    "Editing product. Update the fields and save.",
    "success",
  );
}

function resetProductForm() {
  document.getElementById("productForm").reset();
  document.getElementById("productId").value = "";
  document.getElementById("productImageFile").value = "";
  document.getElementById("cancelProductEdit").classList.add("hidden");
  hideMessage(adminMessage);
}

async function submitProductForm(e) {
  e.preventDefault();
  hideMessage(adminMessage);

  try {
    const name = document.getElementById("productName").value.trim();
    const price = parseFloat(document.getElementById("productPrice").value);
    const imageInput = document.getElementById("productImage").value.trim();
    const imageFile = document.getElementById("productImageFile").files[0];
    let image = imageInput;
    const description = document
      .getElementById("productDescription")
      .value.trim();
    const productId = document.getElementById("productId").value;

    if (!name || isNaN(price)) {
      showMessage(adminMessage, "Name and valid price are required.", "error");
      return;
    }

    if (imageFile) {
      image = await uploadImageFile(imageFile);
    }

    const payload = { name, price, image, description };
    const url = productId
      ? `${baseUrl}/api/products/${productId}`
      : `${baseUrl}/api/products`;
    const method = productId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Unable to save product.");
    }

    showMessage(
      adminMessage,
      data.message || "Product saved successfully.",
      "success",
    );
    resetProductForm();
    loadProducts(true);
    loadProducts(false); // reload public too
  } catch (err) {
    console.error("Error saving product:", err);
    showMessage(
      adminMessage,
      err.message || "Failed to save product.",
      "error",
    );
  }
}

async function deleteProduct(productId) {
  const confirmed = confirm("Delete this product? This cannot be undone.");
  if (!confirmed) return;

  try {
    const res = await fetch(`${baseUrl}/api/products/${productId}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Could not delete product.");
    }

    showMessage(
      adminMessage,
      data.message || "Product removed successfully.",
      "success",
    );
    loadProducts(true);
    loadProducts(false);
  } catch (err) {
    console.error("Error deleting product:", err);
    showMessage(
      adminMessage,
      err.message || "Unable to remove product.",
      "error",
    );
  }
}

async function loadPartners(isAdmin = false) {
  const partnersDiv = document.getElementById(
    isAdmin ? "admin-partners" : "partners",
  );
  partnersDiv.innerHTML =
    "<p class='status-message status-loading'>Loading partners...</p>";

  try {
    const res = await fetch(`${baseUrl}/api/partners`);
    if (!res.ok) {
      throw new Error("Failed to fetch partners");
    }

    const partners = await res.json();
    partnersDiv.innerHTML = "";

    if (!partners.length) {
      partnersDiv.innerHTML = isAdmin
        ? "<p class='status-message status-empty'>No partners available.</p>"
        : "<p class='status-message status-empty'>No partners at the moment.</p>";
      return;
    }

    partners.forEach((partner) => {
      partnersDiv.appendChild(renderPartnerCard(partner, isAdmin));
    });
  } catch (err) {
    console.error("Error loading partners:", err);
    partnersDiv.innerHTML =
      "<p class='status-message status-error'>Unable to load partners. Please try again later.</p>";
  }
}

function renderPartnerCard(partner, isAdmin = false) {
  const card = document.createElement("article");
  card.className = "partner-card";

  const title = document.createElement("h4");
  title.textContent = partner.name;

  const description = document.createElement("p");
  description.textContent = partner.description || "No description available.";
  description.className = "partner-description";

  const logo = document.createElement("img");
  logo.src =
    resolveAssetUrl(partner.logo) ||
    "https://via.placeholder.com/150x150?text=No+Logo";
  logo.alt = partner.name;
  logo.className = "partner-logo";
  attachImagePreview(logo, partner.name, "Partner logo");

  const actions = document.createElement("div");
  actions.className = "button-row";

  if (isAdmin) {
    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "secondary-btn";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => fillPartnerForm(partner));
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "danger-btn";
    deleteBtn.textContent = "Delete";
    deleteBtn.addEventListener("click", () => deletePartner(partner.id));
    actions.appendChild(deleteBtn);
  }

  card.append(title, logo, description, actions);
  return card;
}

function fillPartnerForm(partner) {
  document.getElementById("partnerId").value = partner.id;
  document.getElementById("partnerName").value = partner.name;
  document.getElementById("partnerLogo").value = partner.logo || "";
  document.getElementById("partnerFacebookUrl").value =
    partner.facebook_url || "";
  document.getElementById("partnerTiktokUrl").value = partner.tiktok_url || "";
  document.getElementById("partnerLogoFile").value = "";
  document.getElementById("partnerDescription").value =
    partner.description || "";

  document.getElementById("cancelPartnerEdit").classList.remove("hidden");
  showMessage(
    adminMessage,
    "Editing partner. Update the fields and save.",
    "success",
  );
}

function resetPartnerForm() {
  document.getElementById("partnerForm").reset();
  document.getElementById("partnerId").value = "";
  document.getElementById("partnerLogoFile").value = "";
  document.getElementById("partnerFacebookUrl").value = "";
  document.getElementById("partnerTiktokUrl").value = "";
  document.getElementById("cancelPartnerEdit").classList.add("hidden");
  hideMessage(adminMessage);
}

async function loadGallery() {
  const galleryDiv = document.getElementById("gallery");
  const adminGalleryDiv = document.getElementById("admin-gallery");

  if (galleryDiv) {
    galleryDiv.innerHTML =
      "<p class='status-message status-loading'>Loading gallery...</p>";
  }
  if (adminGalleryDiv && !adminSection.classList.contains("hidden")) {
    adminGalleryDiv.innerHTML =
      "<p class='status-message status-loading'>Loading gallery entries...</p>";
  }

  try {
    const res = await fetch(`${baseUrl}/api/gallery`);
    if (!res.ok) {
      throw new Error("Failed to fetch gallery");
    }

    const galleryItems = await res.json();
    const items = galleryItems.map((item) => ({
      ...item,
      images: normalizeGalleryImages(item.images),
    }));

    if (galleryDiv) {
      galleryDiv.innerHTML = "";
      if (!items.length) {
        galleryDiv.innerHTML =
          "<p class='status-message status-empty'>No gallery moments have been added yet.</p>";
      } else {
        items.forEach((item) => {
          galleryDiv.appendChild(renderGalleryCard(item));
        });
      }
    }

    if (adminGalleryDiv) {
      adminGalleryDiv.innerHTML = "";
      if (adminSection && !adminSection.classList.contains("hidden")) {
        if (!items.length) {
          adminGalleryDiv.innerHTML =
            "<p class='status-message status-empty'>No gallery entries yet.</p>";
        } else {
          items.forEach((item) => {
            adminGalleryDiv.appendChild(
              renderGalleryCard(item, { adminView: true }),
            );
          });
        }
      }
    }
  } catch (err) {
    console.error("Error loading gallery:", err);
    if (galleryDiv) {
      galleryDiv.innerHTML =
        "<p class='status-message status-error'>Unable to load gallery. Please try again later.</p>";
    }
    if (adminGalleryDiv && adminSection && !adminSection.classList.contains("hidden")) {
      adminGalleryDiv.innerHTML =
        "<p class='status-message status-error'>Unable to load gallery entries.</p>";
    }
  }
}

function renderGalleryCard(item, options = {}) {
  const { adminView = false } = options;
  const card = document.createElement("article");
  card.className = "gallery-card";

  const title = document.createElement("h3");
  title.textContent = item.name;

  const description = document.createElement("p");
  description.textContent = item.description || "No description available.";
  description.className = "gallery-description";

  const mediaGrid = document.createElement("div");
  mediaGrid.className = "gallery-media-grid";

  const images = normalizeGalleryImages(item.images);
  images.forEach((imageSrc, index) => {
    const image = document.createElement("img");
    image.src = resolveAssetUrl(imageSrc) || imageSrc;
    image.alt = `${item.name} photo ${index + 1}`;
    image.className = "gallery-image";
    attachImagePreview(image, item.name);
    mediaGrid.appendChild(image);
  });

  const actions = document.createElement("div");
  actions.className = "button-row";

  if (adminView) {
    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "secondary-btn";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => fillGalleryForm(item));
    actions.appendChild(editBtn);

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "danger-btn";
    deleteBtn.textContent = "Delete";
    deleteBtn.addEventListener("click", () => deleteGalleryItem(item.id));
    actions.appendChild(deleteBtn);
  }

  card.append(title, description, mediaGrid, actions);
  return card;
}

function fillGalleryForm(item) {
  currentEditGalleryId = item.id;
  document.getElementById("galleryId").value = item.id;
  document.getElementById("galleryName").value = item.name;
  document.getElementById("galleryDate").value = item.date || "";
  document.getElementById("galleryDescription").value = item.description || "";
  document.getElementById("galleryImages").value = JSON.stringify(
    normalizeGalleryImages(item.images),
  );
  document.getElementById("galleryImageFiles").value = "";
  document.getElementById("cancelGalleryEdit").classList.remove("hidden");
  showMessage(adminMessage, "Editing gallery entry. Update the fields and save.", "success");
}

function resetGalleryForm() {
  currentEditGalleryId = null;
  document.getElementById("galleryForm").reset();
  document.getElementById("galleryId").value = "";
  document.getElementById("galleryImages").value = "";
  document.getElementById("galleryImageFiles").value = "";
  document.getElementById("cancelGalleryEdit").classList.add("hidden");
  hideMessage(adminMessage);
}

async function submitGalleryForm(event) {
  event.preventDefault();
  hideMessage(adminMessage);

  try {
    const name = document.getElementById("galleryName").value.trim();
    const date = document.getElementById("galleryDate").value;
    const description = document.getElementById("galleryDescription").value.trim();
    const existingImages = normalizeGalleryImages(
      document.getElementById("galleryImages").value,
    );
    const newFiles = document.getElementById("galleryImageFiles").files;

    if (!name || !date) {
      showMessage(adminMessage, "Event name and date are required.", "error");
      return;
    }

    let images = existingImages;
    if (newFiles && newFiles.length) {
      images = existingImages.concat(
        await uploadGalleryImages(Array.from(newFiles)),
      );
    }

    if (!images.length) {
      showMessage(
        adminMessage,
        "Please add at least one picture for the gallery entry.",
        "error",
      );
      return;
    }

    const payload = { name, date, description, images };
    const url = currentEditGalleryId
      ? `${baseUrl}/api/gallery/${currentEditGalleryId}`
      : `${baseUrl}/api/gallery`;
    const method = currentEditGalleryId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Unable to save gallery entry.");
    }

    showMessage(
      adminMessage,
      data.message || "Gallery entry saved successfully.",
      "success",
    );
    resetGalleryForm();
    loadGallery();
  } catch (err) {
    console.error("Error saving gallery entry:", err);
    showMessage(
      adminMessage,
      err.message || "Failed to save gallery entry.",
      "error",
    );
  }
}

async function deleteGalleryItem(galleryId) {
  const confirmed = confirm("Delete this gallery entry? This cannot be undone.");
  if (!confirmed) return;

  try {
    const res = await fetch(`${baseUrl}/api/gallery/${galleryId}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Could not delete gallery entry.");
    }

    showMessage(
      adminMessage,
      data.message || "Gallery entry removed successfully.",
      "success",
    );
    if (String(currentEditGalleryId) === String(galleryId)) {
      resetGalleryForm();
    }
    loadGallery();
  } catch (err) {
    console.error("Error deleting gallery entry:", err);
    showMessage(
      adminMessage,
      err.message || "Unable to remove gallery entry.",
      "error",
    );
  }
}

async function submitPartnerForm(e) {
  e.preventDefault();
  hideMessage(adminMessage);

  try {
    const name = document.getElementById("partnerName").value.trim();
    const logoInput = document.getElementById("partnerLogo").value.trim();
    const logoFile = document.getElementById("partnerLogoFile").files[0];
    const facebookUrl = document
      .getElementById("partnerFacebookUrl")
      .value.trim();
    const tiktokUrl = document
      .getElementById("partnerTiktokUrl")
      .value.trim();
    let logo = logoInput;
    const description = document
      .getElementById("partnerDescription")
      .value.trim();
    const partnerId = document.getElementById("partnerId").value;

    if (!name) {
      showMessage(adminMessage, "Partner name is required.", "error");
      return;
    }

    if (logoFile) {
      logo = await uploadImageFile(logoFile);
    }

    const payload = {
      name,
      logo,
      description,
      facebook_url: facebookUrl,
      tiktok_url: tiktokUrl,
    };
    const url = partnerId
      ? `${baseUrl}/api/partners/${partnerId}`
      : `${baseUrl}/api/partners`;
    const method = partnerId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Unable to save partner.");
    }

    showMessage(
      adminMessage,
      data.message || "Partner saved successfully.",
      "success",
    );
    resetPartnerForm();
    loadPartners(true);
    loadPartners(false);
  } catch (err) {
    console.error("Error saving partner:", err);
    showMessage(
      adminMessage,
      err.message || "Failed to save partner.",
      "error",
    );
  }
}

async function deletePartner(partnerId) {
  const confirmed = confirm("Delete this partner? This cannot be undone.");
  if (!confirmed) return;

  try {
    const res = await fetch(`${baseUrl}/api/partners/${partnerId}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Could not delete partner.");
    }

    showMessage(
      adminMessage,
      data.message || "Partner removed successfully.",
      "success",
    );
    loadPartners(true);
    loadPartners(false);
  } catch (err) {
    console.error("Error deleting partner:", err);
    showMessage(
      adminMessage,
      err.message || "Unable to remove partner.",
      "error",
    );
  }
}

async function loadOrders() {
  const ordersDiv = document.getElementById("orders");
  ordersDiv.innerHTML =
    "<p class='status-message status-loading'>Loading orders...</p>";

  try {
    const res = await fetch(`${baseUrl}/api/orders`);
    if (!res.ok) {
      throw new Error("Failed to fetch orders");
    }

    const orders = await res.json();
    ordersDiv.innerHTML = "";

    if (!orders.length) {
      ordersDiv.innerHTML =
        "<p class='status-message status-empty'>No orders yet.</p>";
      return;
    }

    orders.forEach((order) => {
      ordersDiv.appendChild(renderOrderCard(order));
    });
  } catch (err) {
    console.error("Error loading orders:", err);
    ordersDiv.innerHTML =
      "<p class='status-message status-error'>Unable to load orders. Please try again later.</p>";
  }
}

function renderOrderCard(order) {
  const card = document.createElement("article");
  card.className = "order-card";

  const title = document.createElement("p");
  title.className = "order-title";
  title.innerHTML = `<strong>${escapeHtml(order.customer_name)}</strong> | ${escapeHtml(order.customer_email)}`;

  const details = document.createElement("p");
  details.textContent = `${order.product_name} x${order.quantity} - ${formatCurrency(order.total)} (${order.status})`;

  const meta = document.createElement("p");
  meta.className = "order-meta";
  meta.textContent = `Ordered on ${formatDate(order.order_date)} | Phone: ${order.customer_phone}`;

  const actions = document.createElement("div");
  actions.className = "button-row";

  if (order.status === "pending") {
    const completeBtn = document.createElement("button");
    completeBtn.type = "button";
    completeBtn.className = "primary-btn";
    completeBtn.textContent = "Mark Complete";
    completeBtn.addEventListener("click", () =>
      updateOrderStatus(order.id, "completed"),
    );
    actions.appendChild(completeBtn);
  }

  const deleteBtn = document.createElement("button");
  deleteBtn.type = "button";
  deleteBtn.className = "danger-btn";
  deleteBtn.textContent = "Delete";
  deleteBtn.addEventListener("click", () => deleteOrder(order.id));
  actions.appendChild(deleteBtn);

  card.append(title, details, meta, actions);
  return card;
}

async function updateOrderStatus(orderId, status) {
  try {
    const res = await fetch(`${baseUrl}/api/orders/${orderId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Failed to update order");
    }

    showMessage(
      adminMessage,
      data.message || "Order updated successfully.",
      "success",
    );
    loadOrders();
  } catch (err) {
    console.error("Error updating order:", err);
    showMessage(
      adminMessage,
      err.message || "Failed to update order.",
      "error",
    );
  }
}

async function deleteOrder(orderId) {
  const confirmed = confirm("Delete this order? This cannot be undone.");
  if (!confirmed) return;

  try {
    const res = await fetch(`${baseUrl}/api/orders/${orderId}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Could not delete order.");
    }

    showMessage(
      adminMessage,
      data.message || "Order removed successfully.",
      "success",
    );
    loadOrders();
  } catch (err) {
    console.error("Error deleting order:", err);
    showMessage(
      adminMessage,
      err.message || "Unable to remove order.",
      "error",
    );
  }
}

async function loadRegistrations() {
  const regDiv = document.getElementById("registrations");
  regDiv.innerHTML =
    "<p class='status-message status-loading'>Loading registrations...</p>";
  hideMessage(adminMessage);

  try {
    const res = await fetch(`${baseUrl}/api/registrations`);
    if (!res.ok) {
      throw new Error("Failed to fetch registrations");
    }

    const registrations = await res.json();

    if (!registrations.length) {
      regDiv.innerHTML =
        "<p class='status-message status-empty'>No registrations yet.</p>";
      return;
    }

    regDiv.innerHTML = "";
    regDiv.appendChild(renderRegistrationTable(registrations));
  } catch (err) {
    console.error("Error loading registrations:", err);
    regDiv.innerHTML =
      "<p class='status-message status-error'>Cannot load registrations right now.</p>";
  }
}

function renderRegistrationTable(registrations) {
  const wrapper = document.createElement("div");
  wrapper.className = "table-wrap registrations-table-wrap";

  const table = document.createElement("table");
  table.className = "registrations-table";

  const thead = document.createElement("thead");
  thead.innerHTML = `
    <tr>
      <th>Name</th>
      <th>Event</th>
      <th>Notes</th>
      <th>Status</th>
      <th class="table-actions-col">More</th>
    </tr>
  `;

  const tbody = document.createElement("tbody");

  registrations.forEach((registration) => {
    const allergyText = String(registration.food_allergies || "").trim();
    const otherInfoText = String(registration.additional_info || "").trim();
    const hasNotes = Boolean(allergyText || otherInfoText);
    const notePreview = hasNotes ? allergyText || otherInfoText : "No extra notes";
    const registrationId = registration.id;

    const statusPill = registration.paid
      ? `<span class="status-pill status-pill-success">Paid</span>`
      : `<span class="status-pill status-pill-warn">Not Paid</span>`;
    const ticketPill = registration.ticket_sent
      ? `<span class="status-pill status-pill-info">Ticket Sent</span>`
      : `<span class="status-pill status-pill-muted">No Ticket</span>`;

    const summaryRow = document.createElement("tr");
    summaryRow.className = "registration-summary-row";
    summaryRow.innerHTML = `
      <td data-label="Name">
        <div class="registration-main">
          <strong>${escapeHtml(registration.name)}</strong>
        </div>
      </td>
      <td data-label="Event">
        <div class="registration-main">
          <strong>${escapeHtml(registration.event_name)}</strong>
          <span>${escapeHtml(formatDate(registration.event_date))}</span>
        </div>
      </td>
      <td data-label="Status">
        <div class="status-group">
          ${statusPill}
          ${ticketPill}
        </div>
      </td>
      <td data-label="More" class="table-actions">
        <button
          type="button"
          class="secondary-btn registration-toggle-btn"
          data-action="toggle-registration-details"
          data-id="${registrationId}"
          aria-expanded="false"
        >
          See more
        </button>
      </td>
    `;

    const detailsRow = document.createElement("tr");
    detailsRow.className = "registration-details-row hidden";
    detailsRow.dataset.detailsFor = String(registrationId);
    detailsRow.innerHTML = `
      <td colspan="4">
        <div class="registration-details-grid">
          <div class="registration-detail-card">
            <span class="detail-label">Email</span>
            <span class="detail-value">${escapeHtml(registration.email)}</span>
          </div>
          <div class="registration-detail-card">
            <span class="detail-label">Contact</span>
            <span class="detail-value">${escapeHtml(registration.phone)}</span>
          </div>
          <div class="registration-detail-card registration-detail-card-notes">
            <span class="detail-label">Notes</span>
            <div class="notes-content compact-notes">
              <p><strong>Allergies:</strong> ${escapeHtml(allergyText || "None")}</p>
              <p><strong>Other:</strong> ${escapeHtml(otherInfoText || "None")}</p>
              <p class="notes-preview"><strong>Preview:</strong> ${escapeHtml(notePreview)}</p>
            </div>
          </div>
          <div class="registration-detail-card registration-detail-card-actions">
            <span class="detail-label">Actions</span>
            <div class="button-row button-row-tight">
              ${
                !registration.paid
                  ? `<button type="button" class="primary-btn registration-action-btn" data-action="mark-paid" data-id="${registrationId}">Mark Paid</button>`
                  : ""
              }
              ${
                registration.paid && !registration.ticket_sent
                  ? `<button type="button" class="primary-btn registration-action-btn" data-action="send-ticket" data-id="${registrationId}">Send Ticket</button>`
                  : ""
              }
              ${
                registration.paid && registration.ticket_sent
                  ? `<button type="button" class="secondary-btn registration-action-btn" data-action="resend-ticket" data-id="${registrationId}">Resend Ticket</button>`
                  : ""
              }
              <button type="button" class="danger-btn registration-action-btn" data-action="remove-registration" data-id="${registrationId}">
                Remove
              </button>
            </div>
          </div>
        </div>
      </td>
    `;

    tbody.append(summaryRow, detailsRow);
  });

  table.append(thead, tbody);
  wrapper.appendChild(table);
  wrapper.addEventListener("click", (event) => {
    const button = event.target.closest("button[data-action][data-id]");
    if (!button) return;

    const registrationId = Number(button.dataset.id);
    const action = button.dataset.action;

    if (action === "mark-paid") {
      markRegistrationPaid(registrationId);
      return;
    }

    if (action === "send-ticket") {
      sendTicketToRegistrant(registrationId);
      return;
    }

    if (action === "resend-ticket") {
      resendTicketToRegistrant(registrationId);
      return;
    }

    if (action === "remove-registration") {
      deleteRegistration(registrationId);
      return;
    }

    if (action === "toggle-registration-details") {
      const detailsRow = wrapper.querySelector(
        `tr[data-details-for="${registrationId}"]`,
      );
      if (!detailsRow) return;

      const isHidden = detailsRow.classList.contains("hidden");
      detailsRow.classList.toggle("hidden");
      button.setAttribute("aria-expanded", String(isHidden));
      button.textContent = isHidden ? "See less" : "See more";
    }
  });
  return wrapper;
}

async function markRegistrationPaid(registrationId) {
  const confirmed = confirm("Mark this registration as paid?");
  if (!confirmed) return;

  try {
    const res = await fetch(`${baseUrl}/api/registrations/${registrationId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ paid: 1 }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Failed to update registration");
    }

    showMessage(
      adminMessage,
      "Registration marked as paid. Now you can send the ticket!",
      "success",
    );
    loadRegistrations();
  } catch (err) {
    console.error("Error updating registration:", err);
    showMessage(
      adminMessage,
      err.message || "Failed to mark as paid.",
      "error",
    );
  }
}

async function sendTicketToRegistrant(registrationId) {
  try {
    const res = await fetch(`${baseUrl}/api/tickets/send/${registrationId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Failed to send ticket");
    }

    showMessage(adminMessage, data.message, "success");
    loadRegistrations();
  } catch (err) {
    console.error("Error sending ticket:", err);
    showMessage(adminMessage, err.message || "Failed to send ticket.", "error");
  }
}

async function resendTicketToRegistrant(registrationId) {
  // Get the ticket ID first
  try {
    const ticketRes = await fetch(`${baseUrl}/api/tickets`);
    const tickets = await ticketRes.json();
    const ticket = tickets.find((t) => t.registration_id === registrationId);

    if (!ticket) {
      showMessage(adminMessage, "Ticket not found.", "error");
      return;
    }

    const res = await fetch(`${baseUrl}/api/tickets/resend/${ticket.id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Failed to resend ticket");
    }

    showMessage(adminMessage, data.message, "success");
    loadRegistrations();
  } catch (err) {
    console.error("Error resending ticket:", err);
    showMessage(
      adminMessage,
      err.message || "Failed to resend ticket.",
      "error",
    );
  }
}

async function deleteRegistration(registrationId) {
  const confirmed = confirm("Remove this registration? This cannot be undone.");
  if (!confirmed) return;

  try {
    const res = await fetch(`${baseUrl}/api/registrations/${registrationId}`, {
      method: "DELETE",
    });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Failed to delete registration.");
    }

    showMessage(
      adminMessage,
      data.message || "Registration removed.",
      "success",
    );
    loadRegistrations();
  } catch (err) {
    console.error("Error deleting registration:", err);
    showMessage(
      adminMessage,
      err.message || "Unable to remove registration.",
      "error",
    );
  }
}

async function exportRegistrations() {
  try {
    const res = await fetch(`${baseUrl}/api/registrations/export`);
    if (!res.ok) {
      throw new Error("Unable to download CSV.");
    }

    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "registrations.csv";
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.URL.revokeObjectURL(url);
  } catch (err) {
    console.error("CSV export failed:", err);
    showMessage(
      adminMessage,
      err.message || "Could not export registrations.",
      "error",
    );
  }
}

function hideAdminPanel() {
  setAdminMode(false);
  resetEventForm();
  resetGalleryForm();
  resetProductForm();
  resetPartnerForm();
  hideMessage(adminMessage);
}

function openAdminLogin() {
  if (!adminAuthenticated) {
    showAdminLoginForm();
    hideAdminAccessMessage();
    return;
  }

  if (adminSection.classList.contains("hidden")) {
    setAdminMode(true);
  } else {
    hideAdminPanel();
  }
}

async function submitAdminLogin(event) {
  event.preventDefault();
  hideAdminAccessMessage();

  const password = adminPasswordInput ? adminPasswordInput.value : "";
  if (!password.trim()) {
    showAdminAccessMessage("Please enter the admin password.", "error");
    return;
  }

  try {
    const res = await fetch(`${baseUrl}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.message || "Unable to sign in.");
    }

    adminAuthenticated = true;
    hideAdminLoginForm();
    setAdminMode(true);
    showAdminAccessMessage(data.message || "Admin dashboard unlocked.", "success");
    hideMessage(mainMessage);
  } catch (err) {
    adminAuthenticated = false;
    updateAdminControls();
    showAdminAccessMessage(err.message || "Admin sign in failed.", "error");
    if (adminPasswordInput) {
      adminPasswordInput.focus();
      adminPasswordInput.select();
    }
  }
}

async function logoutAdmin() {
  try {
    await fetch(`${baseUrl}/api/auth/logout`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("Logout request failed:", err);
  } finally {
    adminAuthenticated = false;
    hideAdminAccessMessage();
    hideAdminLoginForm();
    hideAdminPanel();
    updateAdminControls();
    showAdminAccessMessage("You have been signed out.", "success");
  }
}

function initialize() {
  const adminToggle = document.getElementById("adminToggle");
  const adminLoginFormElement = document.getElementById("adminLoginForm");
  const cancelAdminLogin = document.getElementById("cancelAdminLogin");
  const registerForm = document.getElementById("registerForm");
  const closeModalButton = document.getElementById("closeRegistrationModal");
  const cancelRegistration = document.getElementById("cancelRegistration");
  const eventForm = document.getElementById("eventForm");
  const cancelEdit = document.getElementById("cancelEdit");
  const galleryForm = document.getElementById("galleryForm");
  const cancelGalleryEdit = document.getElementById("cancelGalleryEdit");
  const refreshRegistrationsBtn = document.getElementById(
    "refreshRegistrations",
  );
  const exportCsvBtn = document.getElementById("exportCsv");
  const productForm = document.getElementById("productForm");
  const cancelProductEdit = document.getElementById("cancelProductEdit");
  const partnerForm = document.getElementById("partnerForm");
  const cancelPartnerEdit = document.getElementById("cancelPartnerEdit");
  const orderForm = document.getElementById("orderForm");
  const closeOrderModalButton = document.getElementById("closeOrderModal");
  const cancelOrder = document.getElementById("cancelOrder");
  const closeImageViewerButton = document.getElementById("closeImageViewer");

  updateAdminControls();

  if (adminToggle) {
    adminToggle.addEventListener("click", () => {
      if (!adminAuthenticated) {
        showAdminLoginForm();
      } else if (adminSection.classList.contains("hidden")) {
        setAdminMode(true);
      } else {
        hideAdminPanel();
      }
    });
  }

  if (adminLoginFormElement) {
    adminLoginFormElement.addEventListener("submit", submitAdminLogin);
  }

  if (cancelAdminLogin) {
    cancelAdminLogin.addEventListener("click", hideAdminLoginForm);
  }

  if (adminLogoutButton) {
    adminLogoutButton.addEventListener("click", logoutAdmin);
  }

  if (registerForm) {
    registerForm.addEventListener("submit", submitRegistration);
  }

  if (closeModalButton) {
    closeModalButton.addEventListener("click", closeRegistrationModal);
  }

  if (cancelRegistration) {
    cancelRegistration.addEventListener("click", closeRegistrationModal);
  }

  if (eventForm) {
    eventForm.addEventListener("submit", submitEventForm);
  }

  if (cancelEdit) {
    cancelEdit.addEventListener("click", resetEventForm);
  }

  if (galleryForm) {
    galleryForm.addEventListener("submit", submitGalleryForm);
  }

  if (cancelGalleryEdit) {
    cancelGalleryEdit.addEventListener("click", resetGalleryForm);
  }

  if (refreshRegistrationsBtn) {
    refreshRegistrationsBtn.addEventListener("click", loadRegistrations);
  }

  if (exportCsvBtn) {
    exportCsvBtn.addEventListener("click", exportRegistrations);
  }

  if (productForm) {
    productForm.addEventListener("submit", submitProductForm);
  }

  if (cancelProductEdit) {
    cancelProductEdit.addEventListener("click", resetProductForm);
  }

  if (partnerForm) {
    partnerForm.addEventListener("submit", submitPartnerForm);
  }

  if (cancelPartnerEdit) {
    cancelPartnerEdit.addEventListener("click", resetPartnerForm);
  }

  if (orderForm) {
    orderForm.addEventListener("submit", submitOrder);
  }

  if (closeOrderModalButton) {
    closeOrderModalButton.addEventListener("click", closeOrderModal);
  }

  if (cancelOrder) {
    cancelOrder.addEventListener("click", closeOrderModal);
  }

  if (registrationModal) {
    registrationModal.addEventListener("click", (event) => {
      if (event.target === registrationModal) {
        closeRegistrationModal();
      }
    });
  }

  if (orderModal) {
    orderModal.addEventListener("click", (event) => {
      if (event.target === orderModal) {
        closeOrderModal();
      }
    });
  }

  if (imageViewerModal) {
    imageViewerModal.addEventListener("click", (event) => {
      if (event.target === imageViewerModal) {
        closeImageViewer();
      }
    });
  }

  if (closeImageViewerButton) {
    closeImageViewerButton.addEventListener("click", closeImageViewer);
  }

  document
    .querySelectorAll("img[data-preview-title]")
    .forEach((image) => {
      attachImagePreview(image, image.dataset.previewTitle);
    });

  document.addEventListener("keydown", (event) => {
    if (
      event.key === "Escape" &&
      imageViewerModal &&
      !imageViewerModal.classList.contains("hidden")
    ) {
      closeImageViewer();
    }
  });

  loadEvents();
  loadGallery();
  loadProducts(false);
  loadPartners(false);
  checkAdminSession();
}

document.addEventListener("DOMContentLoaded", initialize);
